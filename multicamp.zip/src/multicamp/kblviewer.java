package multicamp;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

import org.jfree.chart.ChartPanel;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardCategoryToolTipGenerator;
import org.jfree.chart.plot.SpiderWebPlot;
import org.jfree.chart.title.TextTitle;
import org.jfree.data.category.DefaultCategoryDataset;

import com.teamdev.jxbrowser.chromium.Browser;
import com.teamdev.jxbrowser.chromium.swing.BrowserView;

import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTextPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JPanel;


import java.awt.*;
import org.jfree.ui.*;
import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.chart.labels.*;
import org.jfree.chart.title.*;
import org.jfree.data.category.*;

public class kblviewer {

	private JFrame frame;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					kblviewer window = new kblviewer();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public kblviewer() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 847, 591);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("New button");
		btnNewButton.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
			}
		});
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnNewButton.setBounds(98, 132, 97, 23);
		frame.getContentPane().add(btnNewButton);
		
		JTextPane textPane = new JTextPane();
		textPane.setBounds(274, 132, 125, 23);
		frame.getContentPane().add(textPane);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS);
		scrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);
		scrollPane.setBounds(140, 264, 656, 266);
		frame.getContentPane().add(scrollPane);
		
        
		table = new JTable();
		scrollPane.setViewportView(table);
		table.setColumnSelectionAllowed(true);
		table.setShowGrid(false);
		table.setCellSelectionEnabled(true);
		table.setModel(new DefaultTableModel(
			new Object[][] {
				{"1", "2", 3, "4", null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
				{null, null, null, null, null, null, null, null, null, null, null, null, null, null, null},
			},
			new String[] {
				"id", "vsteam", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column", "New column"
			}
		));
		File paths = new File("");
		String path = kblviewer.class.getResource("").getPath()+"gd_2.jpg";
		System.out.println(path);
		
		String str2 = "C:\\Users\\Joo\\JAVA\\workspace\\multicamp\\bin\\multicamp\\gd_2.jpg";
		JLabel Imagelabel = new JLabel("new");
		Imagelabel.setBounds(646, 49, 150, 188);
		frame.getContentPane().add(Imagelabel);
		Imagelabel.setIcon(new ImageIcon(str2));
		
		Imagelabel.setPreferredSize(new Dimension(200, 188));
		
		

				
		
		
		String series1 = "First";
        String series2 = "Second";
        String series3 = "Third";
 
        String category1 = "Task Completion";
        String category2 = "Accuracy";
        String category3 = "Sophistication";
        String category4 = "Listening";
        String category5 = "Pronunciation";
 
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        dataset.addValue(5.0, series1, category1);
        dataset.addValue(5.0, series1, category2);
        dataset.addValue(5.0, series1, category3);
        dataset.addValue(5.0, series1, category4);
        dataset.addValue(5.0, series1, category5);
 
        dataset.addValue(2.0, series2, category1);
        dataset.addValue(4.0, series2, category2);
        dataset.addValue(5.0, series2, category3);
        dataset.addValue(3.0, series2, category4);
        dataset.addValue(5.0, series2, category5);
   
         
        SpiderWebPlot plot = new SpiderWebPlot(dataset);
         
        plot.setStartAngle(90);
         
        plot.setInteriorGap(0.20);
         
        plot.setToolTipGenerator(new StandardCategoryToolTipGenerator());
         
        JFreeChart chart = new JFreeChart("", TextTitle.DEFAULT_FONT, plot, false);
         
        ChartUtilities.applyCurrentTheme(chart);
         
        ChartPanel chartPanel = new ChartPanel(chart);
        plot = (SpiderWebPlot) chartPanel.getChart().getPlot();
        dataset = (DefaultCategoryDataset) plot.getDataset();
        chartPanel.setPreferredSize(new Dimension(200, 200));
        chartPanel.setBounds(411, 49, 223, 188);
        frame.getContentPane().add(chartPanel);	
		
		
		
		
		
		
		
		
		
		
		
		/*
		Browser browser = new Browser();
        BrowserView view = new BrowserView(browser);
        
        view.setBounds(431, 49, 150, 188);
        view.setPreferredSize(new Dimension(200, 188));
        frame.getContentPane().add(view);
*/        //browser.loadHTML("<html><body><h1>Hello World!</h1></body></html>");
		
	}
}
